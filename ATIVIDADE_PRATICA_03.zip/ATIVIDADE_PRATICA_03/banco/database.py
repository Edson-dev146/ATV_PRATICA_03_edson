from sqlalchemy import create_engine,sessionmaker
from sqlalchemy.orm import DeclarativeBase

class Base(DeclarativeBase):
    pass

engine = create_engine("sqlite:///biblioteca.db")
SessionLocal = sessionmaker(bind=engine)

